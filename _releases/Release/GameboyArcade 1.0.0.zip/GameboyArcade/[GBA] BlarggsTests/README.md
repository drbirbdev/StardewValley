Includes 

Blargg's test roms (https://gbdev.gg8.se/files/roms/blargg-gb-tests/)
Gekkio's test roms (https://gekkio.fi/files/mooneye-test-suite/)
Droneboy (https://github.com/purefunktion/Droneboy)
144p Test Suite (https://github.com/pinobatch/240p-test-mini)

See individual READMEs for instructions.